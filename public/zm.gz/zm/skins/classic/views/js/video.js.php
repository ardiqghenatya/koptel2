var eventId = '<?= $event['Id'] ?>';

var videoGenSuccessString = '<?= addslashes($SLANG['VideoGenSucceeded']) ?>';
var videoGenFailedString = '<?= addslashes($SLANG['VideoGenFailed']) ?>';
var videoGenProgressString = '<?= addslashes($SLANG['GeneratingVideo']) ?>';
